import { NgModule , CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import {
  MatTableModule,
  MatInputModule,
  MatOptionModule,
  MatSelectModule,
  MatIconModule,
  MatPaginatorModule,
  MatSortModule
} from '@angular/material';
import { SliderModule } from 'angular-image-slider';
import { AppRoutingModule } from './app-routing.module';
import {HistoryPageModule} from './history/history.module';
import {DefaulterDataPageModule} from './defaulter-data/defaulter-data.module';
import {ForecastEntryPageModule} from './forecast-entry/forecast-entry.module';
import {YearlyForecastEntryPageModule} from './yearly-forecast-entry/yearly-forecast-entry.module';
@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule,
    SliderModule,
    MatTableModule,
    MatTableModule,
    MatInputModule,
    MatOptionModule,
    MatSelectModule,
    MatIconModule,
    MatPaginatorModule,
    MatSortModule,
    BrowserAnimationsModule,
    DefaulterDataPageModule,
    HistoryPageModule, YearlyForecastEntryPageModule, ForecastEntryPageModule , IonicModule.forRoot(), AppRoutingModule],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [AppComponent]
})
export class AppModule {}
