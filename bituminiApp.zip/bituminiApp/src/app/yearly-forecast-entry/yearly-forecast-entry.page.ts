import { Component, OnInit, ViewChild } from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
export interface YearlyForeCastData {
  item: string;
  jan: number;
  feb: number;
  depot: string;
}
const YEARLY_FORECAST_DATA: YearlyForeCastData[] = [
  {item: 'Item1', depot : 'Depot 1' , jan: 4, feb: 4},
  {item: 'Item2', depot : 'Depot 1' , jan: 5, feb: 5},
  {item: 'Item5', depot : 'Depot 1' , jan: 8, feb: 4}
];
@Component({
  selector: 'app-yearly-forecast-entry',
  templateUrl: './yearly-forecast-entry.page.html',
  styleUrls: ['./yearly-forecast-entry.page.scss'],
})
export class YearlyForecastEntryPage implements OnInit {
   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['item', 'depot', 'jan', 'feb'];
  dataSource = new MatTableDataSource<YearlyForeCastData>(YEARLY_FORECAST_DATA);
  constructor(private modalController: ModalController) { }

  ngOnInit() {
     this.dataSource.paginator = this.paginator;
     this.dataSource.sort = this.sort;
  }
  async closeModal() {
    await this.modalController.dismiss();
  }
}
