import { Component, OnInit, ViewChild } from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
export interface ForeCastData {
  item: string;
  quantity: number;
  depot: string;
}
const FORECAST_DATA: ForeCastData[] = [
  {item: 'Item1', depot : 'Depot 1' , quantity: 0},
  {item: 'Item2', depot : 'Depot 1' , quantity: 5},
  {item: 'Item5', depot : 'Depot 1' , quantity: 8}
];
@Component({
  selector: 'app-forecast-entry',
  templateUrl: './forecast-entry.page.html',
  styleUrls: ['./forecast-entry.page.scss'],
})
export class ForecastEntryPage implements OnInit {

   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['item', 'depot', 'quantity'];
  dataSource = new MatTableDataSource<ForeCastData>(FORECAST_DATA);
  constructor(private modalController: ModalController) { }

  ngOnInit() {
     this.dataSource.paginator = this.paginator;
     this.dataSource.sort = this.sort;
  }
  async closeModal() {
    await this.modalController.dismiss();
  }
}
