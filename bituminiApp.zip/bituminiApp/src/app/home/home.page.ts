import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {ModalController, NavParams} from '@ionic/angular';
import {ForecastEntryPage} from '../forecast-entry/forecast-entry.page';
import {HistoryPage} from '../history/history.page';
import {YearlyForecastEntryPage} from '../yearly-forecast-entry/yearly-forecast-entry.page';
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  public imagesUrl;
  slideOpts = {
    initialSlide: 0,
    slidesPerView: 1,
    speed: 400
  };
  constructor(private router: Router, private modalController: ModalController) { }

  ngOnInit() {
    this.imagesUrl = [
      'assets/images/nynas-background.jpg',
      'assets/images/nynas-side.jpg'
      ];
  }
  async openModal() {
    const modal: HTMLIonModalElement =
       await this.modalController.create({
          component: ForecastEntryPage,
          componentProps: {},
          backdropDismiss: false
    });
    await modal.present();
}
async openYearlyModal() {
  const modal: HTMLIonModalElement =
     await this.modalController.create({
        component: YearlyForecastEntryPage,
        componentProps: {},
        backdropDismiss: false
  });
  await modal.present();
}
async openHistoryModal() {
  const modal: HTMLIonModalElement =
     await this.modalController.create({
        component: HistoryPage,
        componentProps: {},
        backdropDismiss: false
  });
  await modal.present();
}

}
