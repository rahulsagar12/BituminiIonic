import { Component, OnInit, ViewChild } from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
export interface HistoryData {
  item: string;
  quantity: number;
  depot: string;
  week: number;
  year: number;
}
const HISTORY_DATA: HistoryData[] = [
  {item: 'Napthelene', depot : 'Depot 1' , quantity: 0, week : 10, year : 2018},
  {item: 'Napthelene', depot : 'Depot 1' , quantity: 5, week : 16, year : 2019},
  {item: 'Bitumen', depot : 'Depot 1' , quantity: 8, week : 19, year : 2019}
];
@Component({
  selector: 'app-history-entry',
  templateUrl: './history.page.html',
  styleUrls: ['./history.page.scss'],
})
export class HistoryPage implements OnInit {

   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['item', 'depot', 'quantity', 'week', 'year'];
  dataSource = new MatTableDataSource<HistoryData>(HISTORY_DATA);
  constructor(private modalController: ModalController) { }

  ngOnInit() {
     this.dataSource.paginator = this.paginator;
     this.dataSource.sort = this.sort;
  }
  async closeModal() {
    await this.modalController.dismiss();
  }
}
