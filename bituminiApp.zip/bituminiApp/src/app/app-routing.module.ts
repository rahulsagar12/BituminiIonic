import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'yearly-forecast-entry', loadChildren: './yearly-forecast-entry/yearly-forecast-entry.module#YearlyForecastEntryPageModule' },
  { path: 'forecast-entry', loadChildren: './forecast-entry/forecast-entry.module#ForecastEntryPageModule' },
  { path: 'defaulter-data', loadChildren: './defaulter-data/defaulter-data.module#DefaulterDataPageModule' },
  { path: 'admin-home', loadChildren: './admin-home/admin-home.module#AdminHomePageModule' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
