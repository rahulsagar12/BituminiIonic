import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { DefaulterDataPage } from './defaulter-data.page';
import {
  MatTableModule,
  MatInputModule,
  MatOptionModule,
  MatSelectModule,
  MatIconModule,
  MatPaginatorModule,
  MatSortModule
} from '@angular/material';
const routes: Routes = [
  {
    path: '',
    component: DefaulterDataPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    MatTableModule,
    MatInputModule,
    MatOptionModule,
    MatSelectModule,
    MatIconModule,
    MatPaginatorModule,
    MatSortModule,

    FormsModule,
    IonicModule,
    BrowserAnimationsModule,
    RouterModule.forChild(routes)
  ],
  declarations: [DefaulterDataPage]
})
export class DefaulterDataPageModule {}
