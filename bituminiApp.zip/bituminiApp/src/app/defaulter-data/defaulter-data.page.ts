import { Component, OnInit, ViewChild } from '@angular/core';
import {ModalController, NavParams} from '@ionic/angular';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
export interface DefaulterData {
  item: string;
  action: number;
  depot: string;
}
const DEFAULTER_DATA: DefaulterData[] = [
  {item: 'Item1', depot : 'Depot 1' , action : 0},
  {item: 'Item2', depot : 'Depot 1' , action : 5},
  {item: 'Item3', depot : 'Depot 1' , action : 6},
  {item: 'Item4', depot : 'Depot 1' , action : 7},
  {item: 'Item5', depot : 'Depot 1' , action : 8}
];
@Component({
  selector: 'app-defaulter-data',
  templateUrl: './defaulter-data.page.html',
  styleUrls: ['./defaulter-data.page.scss'],
})
export class DefaulterDataPage implements OnInit {

   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['item', 'depot', 'action'];
  dataSource = new MatTableDataSource<DefaulterData>(DEFAULTER_DATA);
  constructor(private modalController: ModalController) { }

  ngOnInit() {
     this.dataSource.paginator = this.paginator;
     this.dataSource.sort = this.sort;
  }
  async closeModal() {
    await this.modalController.dismiss();
  }
}
