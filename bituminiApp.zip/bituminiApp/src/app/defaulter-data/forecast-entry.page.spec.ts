import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatTableModule } from '@angular/material';
import { ForecastEntryPage } from './forecast-entry.page';

describe('ForecastEntryPage', () => {
  let component: ForecastEntryPage;
  let fixture: ComponentFixture<ForecastEntryPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForecastEntryPage, MatTableModule  ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForecastEntryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
