import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {ModalController, NavParams} from '@ionic/angular';
import {DefaulterDataPage} from '../defaulter-data/defaulter-data.page';
import {ForecastEntryPage} from '../forecast-entry/forecast-entry.page';
import {HistoryPage} from '../history/history.page';
import {YearlyForecastEntryPage} from '../yearly-forecast-entry/yearly-forecast-entry.page';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.page.html',
  styleUrls: ['./admin-home.page.scss'],
})
export class AdminHomePage implements OnInit {

  constructor(private router: Router, private modalController: ModalController) { }

  ngOnInit() {
  }
  async openModal() {
    const modal: HTMLIonModalElement =
       await this.modalController.create({
          component: ForecastEntryPage,
          componentProps: {},
          backdropDismiss: false
    });
    await modal.present();
}
async openYearlyModal() {
  const modal: HTMLIonModalElement =
     await this.modalController.create({
        component: YearlyForecastEntryPage,
        componentProps: {},
        backdropDismiss: false
  });
  await modal.present();
}
async openHistoryModal() {
  const modal: HTMLIonModalElement =
     await this.modalController.create({
        component: HistoryPage,
        componentProps: {},
        backdropDismiss: false
  });
  await modal.present();
}
async openDefaulterModal() {
  const modal: HTMLIonModalElement =
     await this.modalController.create({
        component: DefaulterDataPage,
        componentProps: {},
        backdropDismiss: false
  });
  await modal.present();
}

}
